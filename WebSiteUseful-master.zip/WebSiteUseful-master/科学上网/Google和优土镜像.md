## Google  
 * http://ac.scmor.com
 * https://google.jiongjun.cc
 * https://g.zmirrordemo.com
 * https://www.gotype.tk
 * http://www.hlhmf.com/
 

## YouTube
* https://ytb-pc.zmirrordemo.com
* https://youtube.speeder.cf/ （登陆密码和账号都是speeder.club）
* http://wall.qiqiblog.cn

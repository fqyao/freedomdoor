## 使用须知

### 待定项
* 为贴子、博客或1-3个测试型的ss分享站点，可能存在长期未更新，有待观察
* 正常上网能访问的ss分享站点越来越少了，如果找不到满意的可去待定项看看

### heroku的免费配额与限制
* Network Bandwidth/流量: 2TB/month – Soft
* Shared DB processing/并发数: Max 200msec per second CPU time – Soft
* Dyno RAM usage/使用运行内存: 512MB – Hard
* Slug Size/存储空间: 300MB – Hard
* Request Length/请求时间: 30 seconds – Hard

提示Application error，是由于访问量占用内存溢出或因各项服务流量耗尽而停止服务

### 如果遇到打不开的站点请参考这个教程（推荐）

 https://loremwalker.github.io/fq-book/#/dns&hosts/dnscrypt

### v2ray

https://v2ray.cat/

v2ray的账号分享站点目前较少

## 可用站点

* https://fast.ishadowx.net
* https://shadowsocksr.cat/
* https://en.ss8.fun
* https://ss.freess.org/
* https://ss.ishadowx.com
* http://webosss.com/tool/socket
* https://www.nutgeek.com/ssshadowsocks
* https://share-shadowsocksr.herokuapp.com
* https://share-shadowsocks.herokuapp.com 

## 待定项

* https://freessr.win
* http://zgqx.gq/
* https://5l44.pw/
* https://www.flyzy2005.com/fan-qiang/shadowsocks/free-ss-account/
* https://biulink.club/
* http://www.ssrfx.com
* http://www.vpn168.tk
* https://pdf-lib.org/Home/Details/2638
* https://github.com/ssstk/freess

## 镜像站点

* https://trial.ssbit.win
* http://free-ss.tk

## 科学访问
* https://www.ssrshare.com
* https://get.ishadowx.net
* https://get.freess.today
* https://tool.ssrshare.com/tool/free_ssr
* https://doub.io 
* https://free-ss.site
* https://global.ishadowx.net
* http://www.52ssr.net/
* http://i.wuw.red 
* https://freess.cx
* https://free.yitianjianss.com
* http://freeoutline.org/zh

## ssr订阅源
* https://www.nutgeek.cn/newsubscribe/
* https://prom-php.herokuapp.com/cloudfra_ssr.txt
* http://share-shadowsocks.herokuapp.com/full/subscribe
* http://share-shadowsocksr.herokuapp.com/subscribe?valid=1
* https://raw.githubusercontent.com/ImLaoD/sub/master/ssrshare.com

## 分享邮箱
* toyoooooooooooo@gmail.com (doub.io)
* ye515430@gmail.com (yitianjianss)
* ss@rohankdd.com (free-ss.site)

## 搜索相似的网站

https://www.similarsites.com

## 已失效

https://shadowsocksph.space  
https://free.4kvpn.com  
https://freess.pw  
https://doub.loan  
https://freemz.tk/t/5  
https://52ssr.cn  
http://www.honsuv.com/?post=90  
https://newdoub.com



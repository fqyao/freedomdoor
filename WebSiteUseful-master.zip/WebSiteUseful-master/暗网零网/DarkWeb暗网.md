* https://thehiddenwiki.org/

* http://www.deepwebwar.com/


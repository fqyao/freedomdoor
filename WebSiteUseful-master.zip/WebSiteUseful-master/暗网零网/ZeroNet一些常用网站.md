零搜索：

* https://www.zerogate.tk/lingdu.bit

零123导航：

* https://www.zerogate.tk/0123.bit

海盗湾种子站：

* http://127.0.0.1:43110/1PLAYgDQboKojowD3kwdb3CtWmWaokXvfp/

Kindle电子书：

* http://127.0.0.1:43110/1KHCBG6dmbKXTZNenfwhWZ5x3oDyYyHSD4

中文主题：

* http://127.0.0.1:43110/1NzWeweqJ32aRVdM5UzFnYCszuvG5xV3vS

[关于为什么是127.0.0.1，请看这里，也请自行了解零网，不要发起不必要的issue](https://github.com/loremwalker/WebSiteUseful/issues/8)

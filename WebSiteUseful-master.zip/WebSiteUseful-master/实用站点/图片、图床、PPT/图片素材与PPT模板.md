## 图片素材
* https://pixabay.com
* https://www.deviantart.com
* http://sc.chinaz.com/tupian

## favicon.ico

* http://www.easyicon.net

## 图片转为ASCII
* http://picascii.com
* http://www.makepic.net/Tool/Image2ascii.html

## github徽章与emoji

* https://shields.io/

* https://emojipedia.org/ 

* https://getemoji.com

## PPT模板

* http://www.ypppt.com

* http://www.1ppt.com

* http://www.51pptmoban.com